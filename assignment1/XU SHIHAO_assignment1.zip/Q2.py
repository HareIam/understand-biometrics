s='IamHare'
print (len(s))
print (s.upper())
print (s.lower())
print (s[::-1])