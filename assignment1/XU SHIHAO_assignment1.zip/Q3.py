s='I am Hare'
print(s.replace(" ","-"))