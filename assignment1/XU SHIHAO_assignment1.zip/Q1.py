L = range(1, 101)
sum_num = 0
for i in L:
    sum_num += i
print(sum_num)
